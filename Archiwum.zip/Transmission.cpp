#include "Transmission.h"
#include <algorithm>

Transmission::Transmission() {
    // 0 = luz
    gears_ = {0.0, 3.50, 2.20, 1.50, 1.10, 0.90};
    gear_ = 0;
}

void Transmission::toggleMode() {
    mode_ = (mode_ == ShiftMode::Auto) ? ShiftMode::Manual : ShiftMode::Auto;
}

double Transmission::currentRatio() const {
    if (gear_ < 0 || gear_ >= (int)gears_.size()) return 0.0;
    return gears_[gear_];
}

double Transmission::totalRatio() const {
    return currentRatio() * finalDrive_;
}

void Transmission::shiftUp() {
    if (gear_ < (int)gears_.size() - 1) gear_++;
}

void Transmission::shiftDown() {
    if (gear_ > 0) gear_--;
}

void Transmission::updateAuto(double rpm, double throttle) {
    double up   = upRpm_;
    double down = downRpm_;

    if (throttle > 0.7) { up += 800; down += 200; } // mocniej wkręca zanim zmieni
    if (throttle < 0.2) { up -= 800; down -= 200; } // eco: szybciej zmiana

    if (rpm > up) shiftUp();
    else if (rpm < down) shiftDown();
}
